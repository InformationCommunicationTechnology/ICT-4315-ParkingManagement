package edu.du.ict4315.parkingmanagement; /**
 * @Course: ICT 4315
 * @Project: ParkingManagement
 * @Instructor: Mike Prasad
 */

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @Date: 1/8/23
 * @author lutherchikumba
 *
 */
public class ParkingServiceTest {
      ParkingService parkingService = new ParkingService();
      public ParkingServiceTest() {
      parkingService = new ParkingService();
      }

      @Test
      public void register() {
      }

      @Test
      public void performCommand() {
      }
}